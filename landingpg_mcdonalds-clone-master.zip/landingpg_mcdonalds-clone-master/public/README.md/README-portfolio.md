# udacityPortfolioProject
This repository is for the Udacity Portfolio Project. This is my initial commit for critique by the Udacity reviewers. The 'Future Job Trends Staffing Agency' link is a live website that i am currently building in Wordpress. I am also coding it offline (and other websites) with html5/css3/javascript, as my coding skills grow. 
