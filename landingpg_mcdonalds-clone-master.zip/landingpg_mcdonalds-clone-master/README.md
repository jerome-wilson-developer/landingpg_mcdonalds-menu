My 5 Phases of Web Development:

Phase#1: Planning the Project.
Wireframe ... Prototype ... Pen & Paper ... README.md

Phase#2: Build the basic Minimal Viable Project.
html5_@70% / css3_@70% / javascript-es5_@50% / php7.x_@50% / mysql??_@50% / python3.x_50%. CSS: 

Add borders and background-colors to the main containers. This will show a visual representation of the html structure and the css styling. This also helps with the positioning and sizing of the containers. The contents inside the containers can also be positioned and sized visually, and more easily.

Phase#3: Make the Code more Readable.
Refactor_@50%(1of2); CleanUp Comments_@50%_(2of3); RWA-Make Mobile-1st_@50%(1of2); Test functionality-UX, responsiveness, accessibility, performance(lighthouse audit), readability-UI, readability(web dev code), etc.

Phase#4: Finish building the code for the Minimum Viable Project.
html5_@99% / css3_@90% / javascript-es5_@99% / php7.x_@99% / mysql??_@99% / python3.x_99%.

Phase#5: Finish making the Code more Readable.
Refactor_@99%(2of2); CleanUp Comments_@99%_(3of3); RWA-Make Mobile-1st_@99%(2of2); Test functionality-UX, responsiveness, accessibility, performance(lighthouse audit), readability-UI, readability(web dev code), etc.